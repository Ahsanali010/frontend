// src/main.ts
import { bootstrapApplication } from '@angular/platform-browser';
import {
  provideHttpClient,
  withInterceptorsFromDi,
  HTTP_INTERCEPTORS
} from '@angular/common/http';
import { provideRouter } from '@angular/router';
import { AppComponent } from './app/app.component';
import { HttpErrorInterceptor } from './app/interceptors/http-error.interceptor';
import { routes } from './app/app.routes';    // ← use 'routes', not 'appRoutes'

bootstrapApplication(AppComponent, {
  providers: [
    // 1) Enable HttpClient and pick up any class-based interceptors you register below
    provideHttpClient(withInterceptorsFromDi()),

    // 2) Register your class-based interceptor under the HTTP_INTERCEPTORS token
    { provide: HTTP_INTERCEPTORS, useClass: HttpErrorInterceptor, multi: true },

    // 3) Router
    provideRouter(routes),
  ]
}).catch(err => console.error(err));
