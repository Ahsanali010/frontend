import { HighlightCompletedTodoDirective } from './highlight-completed-todo.directive';

describe('HighlightCompletedTodoDirective', () => {
  it('should create an instance', () => {
    const directive = new HighlightCompletedTodoDirective();
    expect(directive).toBeTruthy();
  });
});
