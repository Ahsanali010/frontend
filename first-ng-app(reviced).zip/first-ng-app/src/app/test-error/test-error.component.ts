// import { Component } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { ApiService } from '../services/api.service';
// import { TrackerService } from '../services/tracker.service';

// @Component({
//   selector: 'app-test-error',
//   standalone: true,
//   imports: [CommonModule],
//   templateUrl: './test-error.component.html',
//   styleUrls: ['./test-error.component.scss'],
// })
// export class TestErrorComponent {
//   responseData: any;
//   errorMessage: string = '';

//   constructor(private api: ApiService, private tracker: TrackerService) {}

//   triggerError(): void {
//     this.api.getData().subscribe({
//       next: (res: any) => {
//         this.responseData = res;
//       },
//       error: (err: any) => {
//         this.errorMessage = 'Error caught in component.';
//         console.warn('Component-level error:', err);

//         // Manually track the error using TrackIt
//         this.tracker.trackError(err, '/test-error');
//       }
//     });
//   }
// }


import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { TrackerService } from '../services/tracker.service';

@Component({
  selector: 'app-test-errors',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './test-error.component.html',
  styleUrls: ['./test-error.component.scss'],
})
export class TestErrorComponent {
  message = '';

  constructor(
    private http: HttpClient,
    private tracker: TrackerService
  ) {}

  // 1) JavaScript runtime error
  triggerRuntimeError(): void {
    try {
      (null as any).doSomething();  // will throw
    } catch (err: any) {
      this.tracker.trackError(err, '/test-error');
    }
  }

  // 2) HTTP 500 error
  trigger500(): void {
    this.http.get('http://localhost:3000/api/server-error').subscribe({
      next: () => {
        this.message = 'Unexpected success';
      },
      error: (err) => {
        this.tracker.trackError(err, '/test-error');
      }
    });
  }
  // 3) HTTP 422 error
  trigger422(): void {
    this.http.get('http://localhost:3000/api/unprocessable').subscribe({
      next: () => {
        this.message = 'Unexpected success';
      },
      error: (err) => {
        this.tracker.trackError(err, '/test-error');
      }
    });
  }
}
