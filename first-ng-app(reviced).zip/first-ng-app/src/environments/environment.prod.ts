export const environment = {
  production: true,
  trackerApi: 'http://localhost:3000/log-error'
};
